# CS-517 Semester Project
Name- Nikhil Kumar Bhavani
UIN-01231130
Programming language-Python
Input Library source-[link](https://git.cs.odu.edu/tkennedy/cs417-lecture-examples/tree/master/SemesterProject-CPU-Temps/)
Project overview- This project is to make a program that tkaes in text files containing temperatures of cores in a cpu and use interpolation on it. 